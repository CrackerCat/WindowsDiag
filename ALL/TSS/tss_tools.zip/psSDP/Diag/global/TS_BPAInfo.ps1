﻿#************************************************
# TS_BPAInfo.ps1
# Version 1.5.6
# Date: 12-10-2010 / 2019 WalterE
# Author: Andre Teixeira - andret@microsoft.com
# Description: - This script is used to obtain a report from any inbox BPA Module information or other BPAs with MBCA support.
#************************************************
# 2019-07-30 WalterE added Trap #_#

Param ($BPAModelID = $null, $OutputFileName, $ReportTitle, $ModuleName="BestPractices", $InvokeCommand="Invoke-BpaModel", $GetBPAModelCommand="Get-BPAModel", $GetBPAResultCommand="Get-BpaResult")

Trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "TS_BPAInfo.ps1 Error, ReportTitle: $ReportTitle, BPAModelID: $BPAModelID"
		 #_# Handle exception and throw it to the stdout log file. Then continue with function and script.
			 $Script:ExceptionMessage = $_
			 "[info]: Exception occurred."  | WriteTo-StdOut
			 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
	continue 
}

Function Write-ScriptProgress ($Activity = "", $Status = "") {
	if ($Activity -ne $LastActivity) {
		if (-not $TroubleShootingModuleLoaded -and ($Activity -ne "")) {
			$Activity | Out-Host
		}
		if ($Activity -ne "") {
			Set-variable -Name "LastActivity" -Value $Activity -Scope "global"
		} else {
			$Activity = $LastActivity
		}	
	}
	if ($TroubleShootingModuleLoaded) {
			Write-DiagProgress -activity $Activity -status $Status
		
	} else {
		"    [" + (Get-Date) + "] " + $Status | Out-Host
	}
}

Function SaveToHTMLFile($SourceXMLDoc, $HTMLFileName)
{
	
	$XMLFilename = $Env:TEMP + "\" + [System.IO.Path]::GetFileNameWithoutExtension($HTMLFileName) + ".XML"
	$SourceXMLDoc.Save($XMLFilename)
	
	[xml] $XSLContent = Get-Content 'BPAInfo.xsl'

	$XSLObject = New-Object System.Xml.Xsl.XslTransform
	$XSLObject.Load($XSLContent)
	$XSLObject.Transform($XMLFilename, $HTMLFilename)
    
	Remove-Item $XMLFilename
	"Output saved to $HTMLFilename" | WriteTo-StdOut -ShortFormat
}

Function AddXMLElement ([xml] $xmlDoc,
						[string] $ElementName="Item", 
						[string] $Value,
						[string] $AttributeName="name", 
						[string] $attributeValue,
						[string] $xpath="/Root")
{
	[System.Xml.XmlElement] $rootElement=$xmlDoc.SelectNodes($xpath).Item(0)
	if ($rootElement -ne $null) { 
		[System.Xml.XmlElement] $element = $xmlDoc.CreateElement($ElementName)
		if ($attributeValue.Length -ne 0) {$element.SetAttribute($AttributeName, $attributeValue)}
		if ($Value.lenght -ne 0) { 
			if ($PowerShellV2) {
				$element.innerXML = $Value
			} else {
				$element.set_InnerXml($Value)
			}
		}
		$x = $rootElement.AppendChild($element)
	} else {
		"Error. Path $xpath returned a null value. Current XML document: `n" + $xmlDoc.OuterXml
	}
}

#***********************************************
#*  Starts here
#***********************************************

if (($ModuleName -eq "BestPractices") -and ($InvokeCommand -eq "Invoke-BpaModel") -and ($OSVersion.Build -lt 7600))
{
	"Inbox BPAs Not Supported on OS Build " + $OSVersion.Build | WriteTo-StdOut
}
else
{
	if (Test-Path (Join-Path $PWD.Path 'BPAInfo.xsl'))
	{
		if ($BPAModelID -ne $null)
		{
			Import-LocalizedData -BindingVariable BPAInfo

			if ((Get-WmiObject -Class Win32_ComputerSystem).DomainRole -gt 1) 
			{ #Server

				if ((Get-Host).Name -ne "Default Host") {
					"Windows Troubleshooting Platform not loaded."
					#_# $TroubleshootingModuleLoaded = $false
					$TroubleshootingModuleLoaded = $true
				} else {
					$TroubleshootingModuleLoaded = $true
				}
				
				Write-ScriptProgress -activity $ReportTitle -status $BPAInfo.ID_BPAStarting
				
				$PowerShellV2 = (((Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\PowerShell\1\PowerShellEngine").PowerShellVersion).Substring(0,1) -ge 2)
				
				$Error.Clear()
				Import-Module $ModuleName
				
				if ($Error.Count -eq 0) 
				{
					$InstalledBPAs = Invoke-Expression "$GetBPAModelCommand"
					
					if ((($InstalledBPAs | where-object {$_.Id -eq $BPAModelID}).Id) -ne $null) 
					{
						
						Write-ScriptProgress -activity $ReportTitle -status $BPAInfo.ID_BPARunning	
						
						$BPAResults = Invoke-Expression "$InvokeCommand $BPAModelID"
						
						if (($BPAResults | where-object {($_.ModelID -eq $BPAModelID) -and ($_.Success -eq $true)}) -ne $null) 
						{
							Write-ScriptProgress -activity $ReportTitle -status $BPAInfo.ID_BPAGenerating	
							$BPAXMLDoc = Invoke-Expression "$GetBPAResultCommand $BPAModelID | ConvertTo-XML"
							
							if ($BPAXMLDoc -ne $null) 
							{
								AddXMLElement -xmlDoc $BPAXMLDoc -ElementName "Machine" -Value $Env:COMPUTERNAME -xpath "/Objects"
								AddXMLElement -xmlDoc $BPAXMLDoc -ElementName "TimeField" -Value ($BPAResults[0].Detail).ScanTime -xpath "/Objects"
								AddXMLElement -xmlDoc $BPAXMLDoc -ElementName "ModelId" -Value ($BPAResults[0].Detail).ModelId -xpath "/Objects"
								AddXMLElement -xmlDoc $BPAXMLDoc -ElementName "ReportTitle" -Value $ReportTitle -xpath "/Objects"
								AddXMLElement -xmlDoc $BPAXMLDoc -ElementName "OutputFileName" -Value $OutputFileName -xpath "/Objects"
								
								SaveToHTMLFile -HTMLFileName $OutputFileName -SourceXMLDoc $BPAXMLDoc
								
								if ($TroubleshootingModuleLoaded) 
								{
									CollectFiles -filesToCollect $OutputFileName -fileDescription $ReportTitle -sectionDescription "Best Practices Analyzer reports"
									
									$XMLName = [System.IO.Path]::GetFileNameWithoutExtension($OutputFileName) + ".xml"
									$BPAXMLDoc.Save($XMLName)
									
									CollectFiles -filesToCollect $XMLName -fileDescription $ReportTitle -sectionDescription "Best Practices Analyzer RAW XML Files" -Verbosity "Debug"
									if ($BPAXMLDoc.SelectNodes("(//Object[(Property[@Name=`'Severity`'] = `'Warning`') or (Property[@Name=`'Severity`'] = `'Error`')])").Count -ne 0) 
									{
										$BPAXMLFile = [System.IO.Path]::GetFullPath($PWD.Path + ("\..\BPAResults.XML"))
										if (Test-Path $BPAXMLFile)
										{
											[xml] $ExistingBPAXMLDoc = Get-Content $BPAXMLFile
											AddXMLElement -xmlDoc $ExistingBPAXMLDoc -xpath "/Root" -ElementName "BPAModel" -Value $BPAXMLDoc.SelectNodes("/Objects").Item(0).InnerXML
											$ExistingBPAXMLDoc.Save($BPAXMLFile)
										} else {
											[xml] $BPAFileXMLDoc = "<Root/>"
											AddXMLElement  -xmlDoc $BPAFileXMLDoc -xpath "/Root" -ElementName "BPAModel" -Value $BPAXMLDoc.SelectNodes("/Objects").Item(0).InnerXML
											$BPAFileXMLDoc.Save($BPAXMLFile)
										}
										Update-DiagRootCause -id RC_BPAInfo -Detected $true
									}
								}
								Write-ScriptProgress -activity $ReportTitle -status "Completed."
							} else {
								"$GetBPAResultCommand did not return any result" | WriteTo-StdOut -ShortFormat
							}
						}
					
					} else {
						$Msg = "ERROR: BPA Module $BPAModelID is not installed. Follow the list of installed BPAs: `r`n"
						foreach ($BPA in $InstalledBPAs) 
						{
							$Msg += "   " + $BPA.Id + "`r`n"
						}
						$Msg | WriteTo-StdOut -ShortFormat
						
					}
				} else {
					"ERROR: Unable to load BestPractices module - $ModuleName"  | WriteTo-StdOut -ShortFormat
				}
			}
		}
		else
		{
			"ERROR: BPAModelID was not specified. BPAInfo not executed"  | WriteTo-StdOut -ShortFormat
		}
	}
	else
	{
		"ERROR: BPAInfo.xsl not found. Make sure to use <Folder source> instead of <File source>" | WriteTo-StdOut -IsError
		"ERROR: BPAInfo.xsl not found. Make sure to use <Folder source> instead of <File source>" | WriteTo-ErrorDebugReport
	}
}
