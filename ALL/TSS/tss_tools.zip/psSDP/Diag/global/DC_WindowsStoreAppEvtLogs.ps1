#************************************************
# DC_WindowsStoreAppEvtLogs.ps1
# Date: 2012/12/11, 2019 WalterE
# Author: v-alyao
#*******************************************************

Trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_ 
	continue 
}


$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------Event Logs - Windows Store Apps
	$sectionDescription = "Event Logs - Windows Store Apps"
	$EventLogNames = "Microsoft-Windows-AppModel-Runtime/Admin", "Microsoft-Windows-TWinUI/Operational", "Microsoft-Windows-AppXDeployment/Operational", "Microsoft-Windows-AppXDeploymentServer/Operational", "Microsoft-Windows-AppXDeploymentServer/Restricted", "Microsoft-Windows-AppxPackaging/Operational"
	$Prefix = "_evt_"
	$Suffix = ""
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}