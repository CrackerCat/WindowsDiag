﻿#************************************************
#Last Updated Date: 05-24-2012
#Updated By: Alec Yao     v-alyao@microsoft.com
#Description: Add two arguments for the script, called $Prefix and $Suffix. It will allow to custermize the filename
#************************************************
Param($Prefix = '', $Suffix = '')
Import-LocalizedData -BindingVariable NetBasicInfoStrings
	
Write-DiagProgress -Activity $NetBasicInfoStrings.ID_NetBasicInfo -Status $NetBasicInfoStrings.ID_NetBasicInfoObtaining
	
Function RunCommand ([string]$cmdToRun="", [string]$OutputFile, [string]$FileDescription="", [string]$CollectFile=$false)
{

	"`r`n" + "-" * ($cmdToRun.Length + 2) + "`r`n[" + $cmdToRun + "]`r`n" + "-" * ($cmdToRun.Length + 2) + "`r`n" | Out-File -FilePath $OutputFile -Append
	$CommandLineToExecute = "cmd.exe /c $cmdToRun >> `"$OutputFile`""

	if ($CollectFile -ne $true) 
	{
		$X = RunCmD -commandToRun $CommandLineToExecute -filesToCollect $OutputFile -CollectFiles $false
	} else {
		$x = RunCmD -commandToRun $CommandLineToExecute -sectionDescription $NetBasicInfoStrings.ID_NetBasicInfo -filesToCollect $OutputFile -fileDescription $FileDescription
	}
	
}

#$OutputFile = $ComputerName + "_TcpIp-Info.txt"
$OutputFile = join-path $pwd.path ($ComputerName + "_" + $Prefix + "TcpIp-Info" + $Suffix + ".txt")

RunCommand -cmdToRun "hostname" -OutputFile $OutputFile
RunCommand -cmdToRun "ipconfig /all" -OutputFile $OutputFile
RunCommand -cmdToRun "arp -a" -OutputFile $OutputFile
RunCommand -cmdToRun "nbtstat -n" -OutputFile $OutputFile
RunCommand -cmdToRun "netstat -ano" -OutputFile $OutputFile
RunCommand -cmdToRun "netstat -anob" -OutputFile $OutputFile
RunCommand -cmdToRun "netstat -anoq" -OutputFile $OutputFile #_#
RunCommand -cmdToRun "reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -OutputFile $OutputFile
#RunCommand -cmdToRun "reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /v EnableTCPChimney" -OutputFile $OutputFile #_#
#RunCommand -cmdToRun "reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /v EnableRSS" -OutputFile $OutputFile #_#
#RunCommand -cmdToRun "reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /v EnableTCPA" -OutputFile $OutputFile #_#
#RunCommand -cmdToRun "reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /v DisableTaskOffload" -OutputFile $OutputFile #_#
if ($OSVersion.Major -ge 6)
{
	RunCommand -cmdToRun "netsh int tcp show global" -OutputFile $OutputFile
	RunCommand -cmdToRun "netsh int ipv4 show offload" -OutputFile $OutputFile
	RunCommand -cmdToRun "netstat -nato -p tcp" -FileDescription "TCP/IP Basic Information" -OutputFile $OutputFile -CollectFile $true
}
else
{
	RunCommand -cmdToRun "netstat -ano -p tcp" -FileDescription "TCP/IP Basic Information" -OutputFile $OutputFile -CollectFile $true
}

#$OutputFile = $ComputerName + "_SMB-Info.txt"
$OutputFile = join-path $pwd.path ($ComputerName + "_" + $Prefix + "SMB-Info" + $Suffix + ".txt")

if ((Get-TSRemote) -lt 2)
{
	RunCommand -cmdToRun "net config workstation" -OutputFile $OutputFile
}

if ((Get-Service "lanmanserver").Status -eq 'Running')
{
	RunCommand -cmdToRun "net config server" -OutputFile $OutputFile
	RunCommand -cmdToRun "net share" -OutputFile $OutputFile
	RunCommand -cmdToRun "net statistics server" -OutputFile $OutputFile
}

RunCommand -cmdToRun "net sessions" -OutputFile $OutputFile
RunCommand -cmdToRun "net use" -OutputFile $OutputFile
RunCommand -cmdToRun "net accounts" -OutputFile $OutputFile
RunCommand -cmdToRun "net statistics workstation" -OutputFile $OutputFile -FileDescription "SMB Basic Information" -CollectFile $true

