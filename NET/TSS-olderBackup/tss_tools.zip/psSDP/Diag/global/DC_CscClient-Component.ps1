﻿#************************************************
# DC_CscClient-Component.ps1
# Version x
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about Client Side Caching (CSC)
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSCscClient -Status $ScriptVariable.ID_CTSCscClientDescription

function RunNetSH ([string]$NetSHCommandToExecute="")
{
	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSCscClient -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"`n`n`n" + "-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
}


function cscWMI ([string]$wmiObject)
{
	$cscWmiObject = get-wmiobject -query "select * from $wmiObject" -EA SilentlyContinue #_# -EA SilentlyContinue
	$cscWmiObjectLen = $cscWmiObject.length
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"WMI object: " + $wmiObject 						 	| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	if ($cscWmiObjectLen -ne 0)
	{
		foreach ($object in $cscWmiObject)
		{
			$object	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"There are no items in this WMI object"	| Out-File -FilePath $OutputFile -append
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
}



$sectionDescription = "CSC Client"

#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$OutputFile= $Computername + "_CscClient_info_wmi.TXT"

"===================================================="			| Out-File -FilePath $OutputFile -append
"Client Side Caching Client WMI Output"							| Out-File -FilePath $OutputFile -append
"===================================================="			| Out-File -FilePath $OutputFile -append
"Overview"														| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"			| Out-File -FilePath $OutputFile -append
"   1. Win32_UserStateConfigurationControls   (W8/WS2012+)"		| Out-File -FilePath $OutputFile -append
"   2. Win32_OfflineFilesCache                (WV/WS2008+)"		| Out-File -FilePath $OutputFile -append
"   3. Win32_OfflineFilesItem                 (WV/WS2008+)"		| Out-File -FilePath $OutputFile -append
"   4. Win32_OfflineFilesMachineConfiguration (W8/WS2012+)"		| Out-File -FilePath $OutputFile -append
"===================================================="			| Out-File -FilePath $OutputFile -append
"`n"															| Out-File -FilePath $OutputFile -append
"`n"															| Out-File -FilePath $OutputFile -append
"`n"															| Out-File -FilePath $OutputFile -append
"`n"															| Out-File -FilePath $OutputFile -append
"`n"															| Out-File -FilePath $OutputFile -append
if ($bn -gt 9000)                               
{
	#----------------------------------------------------
	# USER PROFILE (W8/WS2012+)
	#----------------------------------------------------
	#cscWMI "Win32_UserProfile"							# shows information about each user profile
	cscWMI "Win32_UserStateConfigurationControls"		# shows on/off state of FolderRedirection, OfflineFiles, and RoamingUserProfile

	#----------------------------------------------------
	# OFFLINE FILES (WV/WS2008+)
	#Reference: http://msdn.microsoft.com/en-us/library/bb309180(v=vs.85).aspx
	#----------------------------------------------------
	cscWMI "Win32_OfflineFilesCache"					# shows Active, Enabled, and Location
	cscWMI "Win32_OfflineFilesItem"						# shows ItemName
	#-----
	#cscWMI "Win32_OfflineFilesAssociatedItems"			# "This class is not supported"
	#cscWMI "Win32_OfflineFilesChangeInfo"				# usefulness unknown
	#cscWMI "Win32_OfflineFilesConnectionInfo"			# usefulness unknown
	#cscWMI "Win32_OfflineFilesFileSysInfo"				# usefulness unknown
	#cscWMI "Win32_OfflineFilesPinInfo"					# usefulness unknown
	#cscWMI "Win32_OfflineFilesSuspendInfo"				# usefulness unknown

	#----------------------------------------------------
	# OFFLINE FILES (W8/WS2012+)
	#----------------------------------------------------
	cscWMI "Win32_OfflineFilesMachineConfiguration"		# shows
	#-----
	#cscWMI "Win32_OfflineFilesBackgroundSync"			# usefulness unknown
	#cscWMI "Win32_OfflineFilesDiskSpaceLimit"			# usefulness unknown
	#cscWMI "Win32_OfflineFilesHealth"					# usefulness unknown
	#cscWMI "Win32_OfflineFilesUserConfiguration"		# usefulness unknown
}
elseif ($bn -gt 7000)
{
	#----------------------------------------------------
	# OFFLINE FILES (WV/WS2008+)
	#Reference: http://msdn.microsoft.com/en-us/library/bb309180(v=vs.85).aspx
	#----------------------------------------------------
	cscWMI "Win32_OfflineFilesCache"					# shows Active, Enabled, and Location
	cscWMI "Win32_OfflineFilesItem"						# shows ItemName
	#-----
	#cscWMI "Win32_OfflineFilesAssociatedItems"			# "This class is not supported"
	#cscWMI "Win32_OfflineFilesChangeInfo"				# usefulness unknown
	#cscWMI "Win32_OfflineFilesConnectionInfo"			# usefulness unknown
	#cscWMI "Win32_OfflineFilesFileSysInfo"				# usefulness unknown
	#cscWMI "Win32_OfflineFilesPinInfo"					# usefulness unknown
	#cscWMI "Win32_OfflineFilesSuspendInfo"				# usefulness unknown
}
CollectFiles -filesToCollect $OutputFile -fileDescription "CscClient WMI output" -SectionDescription $sectionDescription



#----------CscClient Registry

$OutputFile= $Computername + "_CscClient_reg_output.TXT"
$CurrentVersionKeys =	"HKCU\SOFTWARE\Policies\Microsoft\Windows\Netcache",
						"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\NetCache",
						"HKLM\SOFTWARE\Policies\Microsoft\NetCache",
						"HKLM\SYSTEM\CurrentControlSet\services\CSC",
						"HKLM\SYSTEM\CurrentControlSet\services\CscService"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "CscClient Registry Keys" -SectionDescription $sectionDescription



#----------CSC Eventlogs
#WV/WS2008+
if ($bn -gt 6000)
{
	#----------CscClient EventLog
	$sectionDescription = "CscClient Eventlogs"
	$EventLogNames = 	"Microsoft-Windows-OfflineFiles/Operational",
						"Microsoft-Windows-OfflineFiles/Analytic",
						"Microsoft-Windows-OfflineFiles/Debug",
						"Microsoft-Windows-OfflineFiles/SyncLog"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}


#----------Driver Information for CSC Client
#$OutputFileSym = "_CscClient"

# Array of file names to pass to checksym
#[array]$arrFileNames = @("cscapi.dll","cscdll.dll","cscmig.dll","cscobj.dll","cscsvc.dll")
# Call DC_ChkSym.ps1 with array of files
#Run-DiagExpression .\DC_ChkSym.ps1 -FolderName "$Env:SystemRoot\System32" -FileMask $arrFileNames -Prefix $OutputFileSym -Suffix "_binaries_dll" -FileDescription "Offline Files and Folders Driver Versions"
#Run-DiagExpression .\DC_ChkSym.ps1 -FolderName "$Env:SystemRoot\System32\drivers" -FileMask "csc.sys" -Prefix $OutputFileSym -Suffix "_binaries_sys" -FileDescription "Offline Files and Folders Driver Versions"
