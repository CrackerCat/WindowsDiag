﻿$debug = $false

$vmmskey = "HKLM:\SYSTEM\CurrentControlSet\Services\vmms"
            
if (Test-Path $vmmskey) { 

	Import-LocalizedData -BindingVariable HyperVNetStrings

	#Hyper-V Networking info

	Write-DiagProgress -Activity $HyperVNetStrings.ID_HyperVNet -Status $HyperVNetStrings.ID_HyperVNetObtaining
	$OutputFile = $Computername + "_Hyper-V-NetworkingInfo.txt"	
	# detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	if ($bn -lt 9200)
	{
		$CommandToExecute = "cmd.exe /c cscript.exe //nologo nvspinfo.js /z > $OutputFile"
	}
	else
	{
		$CommandToExecute = "cmd.exe /c cscript.exe //nologo nvspinfov2.js /z > $OutputFile"
	}
	$FileDescription = "Hyper-V Networking Info"
	$sectionDescription = "Hyper-V Networking Advanced Information"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $FileDescription -BackgroundExecution
}

