﻿#************************************************
# DC_BPA-DS.ps1
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

if (($OSVersion.Build -eq 7600) -or ($OSVersion.Build -eq 7601))
{
	$DomainRole = (Get-WmiObject -Class Win32_ComputerSystem).DomainRole
  
	#Servers
	if ($DomainRole -gt 1)
	{
		if ($DomainRole -ge 4)
		{
			#Domain Controller
			Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/DirectoryServices" -OutputFileName ($Computername + "_AD_BPAInfo.HTM") -ReportTitle "Active Directory Best Practices Analyzer"
		}

		Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/CertificateServices" -OutputFileName ($Computername + "_CertSrv_BPAInfo.HTM") -ReportTitle "Certificate Services Best Practices Analyzer"
		Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/DNSServer" -OutputFileName ($Computername + "_DNS_BPAInfo.HTM") -ReportTitle "DNS Server Best Practices Analyzer"
		Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/TerminalServices" -OutputFileName ($Computername + "_TS_BPAInfo.HTM") -ReportTitle "Terminal Services Server Best Practices Analyzer"

		If ((Get-WmiObject Win32_ServerFeature -Filter "ID=6") -ne $null)
		{
      		Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/FileServices" -OutputFileName ($Computername + "_SMBServer_BPAInfo.HTM") -ReportTitle "FileServices Best Practices Analyzer"
		}
	}
}