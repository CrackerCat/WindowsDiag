﻿
PARAM ([string] $SchemaXMLPath = 'ConfigXPLSchema.xml',
		[string] $WorkingPath = ''
		)

# 2019-03-17 WalterE added Trap #_#
<#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
#>

Trap {WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
. ./utils_cts.ps1

if ([string]::IsNullOrEmpty($WorkingPath))
{
	$WorkingPath = ($PWD.Path)
	#_# $WorkingPath = $global:savePathTmp
}

$UtilsDiscoveryPS1Path = join-path $WorkingPath 'utils_discovery.ps1'

if (-not (Test-Path $UtilsDiscoveryPS1Path))
{
	if (($MyInvocation.ScriptName -ne $null) -and ($MyInvocation.ScriptName.Length -gt 0))
	{
		$ScriptFolder = [System.IO.Path]::GetDirectoryName($MyInvocation.ScriptName)
	}
	
	if (-not (Test-Path $UtilsDiscoveryPS1Path) -and (($MyInvocation.InvocationName -ne $null) -and ($MyInvocation.InvocationName.Length -gt 1)))
	{
		$ScriptFolder = [System.IO.Path]::GetDirectoryName($MyInvocation.InvocationName)
	}
	
	if (-not (Test-Path $UtilsDiscoveryPS1Path) -and (($MyInvocation.MyCommand.Path -ne $null) -and ($MyInvocation.MyCommand.Path.Length -gt 1)))
	{
		$ScriptFolder = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Path)
	}
	
	$UtilsDiscoveryPS1Path = join-path $ScriptFolder 'utils_discovery.ps1'
}

# Check if ConfigXPLSchema.xml is located in $pwd.path - indicating that it is running inside a package. 
# In this case, use Invoke-Expression against the content to avoid issues with PS execution policy

if (Test-Path (Join-Path $PWD.Path 'ConfigXPLSchema.xml'))
{
	$UtilsDiscoveryPS1Content = [string]::Join("`r`n", (get-content -Path $UtilsDiscoveryPS1Path))
	Invoke-Expression ($UtilsDiscoveryPS1Content)
}
else
{
 	. $UtilsDiscoveryPS1Path -WorkingPath $WorkingPath -SchemaXMLPath $SchemaXMLPath
}

If (OpenSchemaXML -SchemaXMLPath $SchemaXMLPath)
{
	$RootDiscoverySet = Get-RootDiscoverySet
	Run-DiscoverySet $RootDiscoverySet
	$LinkedDiscoverySets = Get-DiscoverySetLinks -DiscoverSetGuid $RootDiscoverySet
	$LinkedDiscoverySets | ForEach-Object -Process {
		Run-DiscoverySet $_
	}
}
else	
{
	"Schema XML could not be open. Aborting..."  | CXPLog-WriteLine -IsError
}