#  PSDiagnostics.ps1
# https://github.com/PowerShell/PowerShell/tree/master/src/Modules/Windows/PSDiagnostics
<#
This module can be installed using this command: Install-Module psdiagnostics

Import-Module psdiagnostics
Enable-WSManTrace

  REPRO

Disable-wsmantrace
Copy %windir%\system32\wsmtraces.log to ms_data
#>

[CmdletBinding()]
PARAM (
        [parameter(Mandatory=$false)]
        [ValidateScript({Test-Path $_ -PathType Container})]
        [String] $OutputDirectory = (Split-Path $MyInvocation.MyCommand.Path -Parent)
    )
	
#[string]$scriptPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)
#Write-verbose "scriptPath: $scriptPath"

  # This gets the current path and name of the script.
  $invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
  $scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	Write-Verbose "scriptPath:  $scriptPath - ScriptParentPath: $ScriptParentPath"

Import-Module -Name $ScriptParentPath\PSDiagnostics.psm1   

Write-Host -ForegroundColor White -BackgroundColor DarkGreen "$(Get-Date -Format 'HH:mm:ss') Collecting WSManTrace Diagnostics Data:"
#Write-Verbose "PSBoundParameters: @PSBoundParameters "
Enable-WSManTrace 

Write-Host "Reproduce your issue now; after repro, press ENTER"	
pause
Disable-WSManTrace
Write-Host "..collecting $ENV:Windir\system32\WSMtraces.log"
Copy-Item $ENV:Windir\system32\wsmtraces.log -Destination $OutputDirectory\$ENV:computername`_WSManTraces.etl

Write-Host -ForegroundColor White -BackgroundColor DarkGreen "$(Get-Date -Format 'HH:mm:ss') ..Done WSManTrace Diagnostics Data"
