﻿#************************************************
# DC_GetSQLSetupLogs.ps1
# Version 1.0.0
# Date: 8-19-2011
# Author: Shon Hauck - Shonh@Microsoft.com
# Description: Used to Get SQL Setup Logs (Bootstrap Directory for SQL 9, 10 , 10.5, 11)
#
# NOTE: 
#
#************************************************

# Copyright ?2008, Microsoft Corporation. All rights reserved.

# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.

if($debug -eq $true){[void]$shell.popup("DC_GetSQLSetupLogs.ps1")}

Import-LocalizedData -BindingVariable GetSQLSetupLogs -FileName GetSQLSetupLogsFile -UICulture en-us

#Collect SQL 90 Setup logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2005_Logs

$SQL90Path = (join-path ([Environment]::GetFolderPath("ProgramFiles")) "Microsoft SQL Server\90\Setup Bootstrap\Log")
if($debug -eq $true){[void]$shell.popup($TestPath)}

if ((test-path $SQL90Path) -eq $true)
	{
		if($debug -eq $true){[void]$shell.popup("Valid Path")}
		
		$OutputFileName= $ComputerName + "_SQL90_Bootstrap.Cab"
		if($debug -eq $true){[void]$shell.popup($OutputFileName)}

		#Create Array of Files to Collect
		[Array] $DC_GetSQLLogs90OutputFiles = $SQL90Path + "\*.htm"
		$DC_GetSQLLogs90OutputFiles += $SQL90Path + "\*.log"
		$DC_GetSQLLogs90OutputFiles += $SQL90Path + "\*.xml"
		$DC_GetSQLLogs90OutputFiles += $SQL90Path + "\*.ico"
		$DC_GetSQLLogs90OutputFiles += $SQL90Path + "\*.mft"
		$DC_GetSQLLogs90OutputFiles += $SQL90Path + "\*.Reg_"
		$DC_GetSQLLogs90OutputFiles += $SQL90Path + "\*.tmp"
		$DC_GetSQLLogs90OutputFiles += $SQL90Path + "\*.txt"

		CompressCollectFiles -filesToCollect $DC_GetSQLLogs90OutputFiles -DestinationFileName $OutputFileName -fileDescription "SQL 2005 Bootstrap Logs" -sectionDescription "Additional Data" -Recursive -ForegroundProcess
	}
	else
		{
			if($debug -eq $true){[void]$shell.popup("IN-Valid Path")}
		}

#Collect SQL 100 Setup logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2008_2008R2_Logs

$SQL10Path = (join-path ([Environment]::GetFolderPath("ProgramFiles")) "Microsoft SQL Server\100\Setup Bootstrap\Log")
if($debug -eq $true){[void]$shell.popup($TestPath)}

if ((test-path $SQL10Path) -eq $true)
	{
		if($debug -eq $true){[void]$shell.popup("Valid Path")}
		
		$OutputFileName=  $ComputerName + "_SQL100_Bootstrap.Cab"
		if($debug -eq $true){[void]$shell.popup($OutputFileName)}

		#Create Array of Files to Collect
		[Array] $DC_GetSQLLogs10OutputFiles = $SQL10Path + "\*.htm"
		$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\*.log"
		$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\*.xml"
		$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\*.ico"
		$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\*.mft"
		$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\*.Reg_"
		#$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\*.tmp"
		#$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\Logfiles.cab"
		$DC_GetSQLLogs10OutputFiles += $SQL10Path + "\*.txt"

		CompressCollectFiles -filesToCollect $DC_GetSQLLogs10OutputFiles -DestinationFileName $OutputFileName -fileDescription "SQL 2008 And 2008 R2 Bootstrap Logs" -sectionDescription "Additional Data" -Recursive -ForegroundProcess 
		
	}
	else
		{
			if($debug -eq $true){[void]$shell.popup("IN-Valid Path")}
		}


#Collect SQL 110 Setup logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_Denali_Logs

$SQL11Path = (join-path ([Environment]::GetFolderPath("ProgramFiles")) "Microsoft SQL Server\110\Setup Bootstrap\Log")
if($debug -eq $true){[void]$shell.popup($TestPath)}

if ((test-path $SQL11Path) -eq $true)
	{
		if($debug -eq $true){[void]$shell.popup("Valid Path")}
		
		$OutputFileName= $ComputerName + "_SQL110_Bootstrap.Cab"
		if($debug -eq $true){[void]$shell.popup($OutputFileName)}

		#Create Array of Files to Collect
		[Array] $DC_GetSQLLogs11OutputFiles = $SQL11Path + "\*.htm"
		$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\*.log"
		$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\*.xml"
		$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\*.ico"
		$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\*.mft"
		$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\*.Reg_"
		#$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\*.tmp"
		#$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\Logfiles.cab"
		$DC_GetSQLLogs11OutputFiles += $SQL11Path + "\*.txt"

		CompressCollectFiles -filesToCollect $DC_GetSQLLogs11OutputFiles  -DestinationFileName $OutputFileName -fileDescription "SQL Denali Bootstrap Logs" -sectionDescription "Additional Data" -Recursive -ForegroundProcess
	}
	else
		{
			if($debug -eq $true){[void]$shell.popup("IN-Valid Path")}
		}




# SIG # Begin signature block
# MIIajwYJKoZIhvcNAQcCoIIagDCCGnwCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU9JZTUw+PHkK7l7WZ6i37+ff8
# kB+gghU2MIIEqTCCA5GgAwIBAgITMwAAAIhZDjxRH+JqZwABAAAAiDANBgkqhkiG
# 9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQTAeFw0xMjA3MjYyMDUw
# NDFaFw0xMzEwMjYyMDUwNDFaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCzdHTQgjyH
# p5rUjrIEQoCXJS7kQc6TYzZfE/K0eJiAxih+zIoT7z03jDsJoNgUxVxe2KkdfwHB
# s5gbUHfs/up8Rc9/4SEOxYTKnw9rswk4t3TEVx6+8EioeVrfDpscmqi8yFK1DGmP
# hM5xVXv/CSC/QHc3ITB0W5Xfd8ug5cFyEgY98shVbK/B+2oWJ8j1s2Hj2c4bDx70
# 5M1MNGw+RxHnAitfFHoEB/XXPYvbZ31XPjXrbY0BQI0ah5biD3dMibo4nPuOApHb
# Ig/l0DapuDdF0Cr8lo3BYHEzpYix9sIEMIdbw9cvsnkR2ItlYqKKEWZdfn8FenOK
# H3qF5c0oENE9AgMBAAGjggEdMIIBGTATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNV
# HQ4EFgQUJls+W12WX+L3d4h/XkVTWKguW7gwDgYDVR0PAQH/BAQDAgeAMB8GA1Ud
# IwQYMBaAFMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNp
# Z1BDQV8wOC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKG
# Pmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENB
# XzA4LTMxLTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQAP3kBJiJHRMTejRDhp
# smor1JH7aIWuWLseDI9W+pnXypcnTOiFjnlpLOS9lj/lcGaXlTBlKa3Gyqz1D3mo
# Z79p9A+X4woPv+6WdimyItAzxv+LSa2usv2/JervJ1DA6xn4GmRqoOEXWa/xz+yB
# qInosdIUBuNqbXRSZNqWlCpcaWsf7QWZGtzoZaqIGxWVGtOkUZb9VZX4Y42fFAyx
# nn9KBP/DZq0Kr66k3mP68OrDs7Lrh9vFOK22c9J4ZOrsIVtrO9ZEIvSBUqUrQymL
# DKEqcYJCy6sbftSlp6333vdGms5DOegqU+3PQOR3iEK/RxbgpTZq76cajTo9MwT2
# JSAjMIIEujCCA6KgAwIBAgIKYQKSSgAAAAAAIDANBgkqhkiG9w0BAQUFADB3MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhNaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTIwMTA5MjIyNTU5WhcNMTMwNDA5MjIy
# NTU5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjENMAsG
# A1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNOOkI4RUMtMzBBNC03
# MTQ0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzWPD96K1R9n5OZRTrGuPpnk4IfTR
# bj0VOBbBcyyZj/vgPFvhokyLsquLtPJKx7mTUNEm9YdTsHp180cPFytnLGTrYOdK
# jOCLXsRWaTc6KgRdFwHIv6m308mro5GogeM/LbfY5MR4AHk5z/3HZOIjEnieDHYn
# SY+arA504wZVVUnI7aF8cEVhfrJxFh7hwUG50tIy6VIk8zZQBNfdbzxJ1QvUdkD8
# ZWUTfpVROtX/uJqnV2tLFeU3WB/cAA3FrurfgUf58FKu5s9arOAUSqZxlID6/bAj
# MGDpg2CsDiQe/xHy56VVYpXun3+eKdbNSwp2g/BDBN8GSSDyU1pEsFF6OQIDAQAB
# o4IBCTCCAQUwHQYDVR0OBBYEFM0ZrGFNlGcr9q+UdVnb8FgAg6E6MB8GA1UdIwQY
# MBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY3Jvc29mdFRp
# bWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsGAQUFBzAChjxodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jvc29mdFRpbWVTdGFt
# cFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQEFBQADggEB
# AFEc1t82HdyAvAKnxpnfFsiQBmkVmjK582QQ0orzYikbeY/KYKmzXcTkFi01jESb
# 8fRcYaRBrpqLulDRanlqs2KMnU1RUAupjtS/ohDAR9VOdVKJHj+Wao8uQBQGcu4/
# cFmSXYXtg5n6goSe5AMBIROrJ9bMcUnl2h3/bzwJTtWNZugMyX/uMRQCN197aeyJ
# PkV/JUTnHxrWxRrDSuTh8YSY50/5qZinGEbshGzsqQMK/Xx6Uh2ca6SoD5iSpJJ4
# XCt4432yx9m2cH3fW3NTv6rUZlBL8Mk7lYXlwUplnSVYULsgVJF5OhsHXGpXKK8x
# x5/nwx3uR/0n13/PdNxlxT8wggW8MIIDpKADAgECAgphMyYaAAAAAAAxMA0GCSqG
# SIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAXBgoJkiaJk/IsZAEZ
# FgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eTAeFw0xMDA4MzEyMjE5MzJaFw0yMDA4MzEyMjI5MzJaMHkxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jv
# c29mdCBDb2RlIFNpZ25pbmcgUENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEAsnJZXBkwZL8dmmAgIEKZdlNsPhvWb8zL8epr/pcWEODfOnSDGrcvoDLs
# /97CQk4j1XIA2zVXConKriBJ9PBorE1LjaW9eUtxm0cH2v0l3511iM+qc0R/14Hb
# 873yNqTJXEXcr6094CholxqnpXJzVvEXlOT9NZRyoNZ2Xx53RYOFOBbQc1sFumdS
# jaWyaS/aGQv+knQp4nYvVN0UMFn40o1i/cvJX0YxULknE+RAMM9yKRAoIsc3Tj2g
# Mj2QzaE4BoVcTlaCKCoFMrdL109j59ItYvFFPeesCAD2RqGe0VuMJlPoeqpK8kbP
# Nzw4nrR3XKUXno3LEY9WPMGsCV8D0wIDAQABo4IBXjCCAVowDwYDVR0TAQH/BAUw
# AwEB/zAdBgNVHQ4EFgQUyxHoytK0FlgByTcuMxYWuUyaCh8wCwYDVR0PBAQDAgGG
# MBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFP3RMU7TJoqV4Zhg
# O6gxb6Y8vNgtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMB8GA1UdIwQYMBaA
# FA6sgmBAVieX5SUT/CrhClOVWeSkMFAGA1UdHwRJMEcwRaBDoEGGP2h0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL21pY3Jvc29mdHJvb3Rj
# ZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYBBQUHMAKGOGh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9zb2Z0Um9vdENlcnQuY3J0MA0G
# CSqGSIb3DQEBBQUAA4ICAQBZOT5/Jkav629AsTK1ausOL26oSffrX3XtTDst10Ot
# C/7L6S0xoyPMfFCYgCFdrD0vTLqiqFac43C7uLT4ebVJcvc+6kF/yuEMF2nLpZwg
# LfoLUMRWzS3jStK8cOeoDaIDpVbguIpLV/KVQpzx8+/u44YfNDy4VprwUyOFKqSC
# HJPilAcd8uJO+IyhyugTpZFOyBvSj3KVKnFtmxr4HPBT1mfMIv9cHc2ijL0nsnlj
# VkSiUc356aNYVt2bAkVEL1/02q7UgjJu/KSVE+Traeepoiy+yCsQDmWOmdv1ovoS
# JgllOJTxeh9Ku9HhVujQeJYYXMk1Fl/dkx1Jji2+rTREHO4QFRoAXd01WyHOmMcJ
# 7oUOjE9tDhNOPXwpSJxy0fNsysHscKNXkld9lI2gG0gDWvfPo2cKdKU27S0vF8jm
# cjcS9G+xPGeC+VKyjTMWZR4Oit0Q3mT0b85G1NMX6XnEBLTT+yzfH4qerAr7EydA
# reT54al/RrsHYEdlYEBOsELsTu2zdnnYCjQJbRyAMR/iDlTd5aH75UcQrWSY/1AW
# Lny/BSF64pVBJ2nDk4+VyY3YmyGuDVyc8KKuhmiDDGotu3ZrAB2WrfIWe/YWgyS5
# iM9qqEcxL5rc43E91wB+YkfRzojJuBj6DnKNwaM9rwJAav9pm5biEKgQtDdQCNbD
# PTCCBgcwggPvoAMCAQICCmEWaDQAAAAAABwwDQYJKoZIhvcNAQEFBQAwXzETMBEG
# CgmSJomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsG
# A1UEAxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTA3
# MDQwMzEyNTMwOVoXDTIxMDQwMzEzMDMwOVowdzELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn6Fssd/bSJIqfGsu
# GeG94uPFmVEjUK3O3RhOJA/u0afRTK10MCAR6wfVVJUVSZQbQpKumFwwJtoAa+h7
# veyJBw/3DgSY8InMH8szJIed8vRnHCz8e+eIHernTqOhwSNTyo36Rc8J0F6v0LBC
# BKL5pmyTZ9co3EZTsIbQ5ShGLieshk9VUgzkAyz7apCQMG6H81kwnfp+1pez6CGX
# fvjSE/MIt1NtUrRFkJ9IAEpHZhEnKWaol+TTBoFKovmEpxFHFAmCn4TtVXj+AZod
# UAiFABAwRu233iNGu8QtVJ+vHnhBMXfMm987g5OhYQK1HQ2x/PebsgHOIktU//kF
# w8IgCwIDAQABo4IBqzCCAacwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUIzT4
# 2VJGcArtQPt2+7MrsMM1sw8wCwYDVR0PBAQDAgGGMBAGCSsGAQQBgjcVAQQDAgEA
# MIGYBgNVHSMEgZAwgY2AFA6sgmBAVieX5SUT/CrhClOVWeSkoWOkYTBfMRMwEQYK
# CZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYD
# VQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHmCEHmtFqFK
# oKWtTHNY9AcTLmUwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3Nv
# ZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQG
# CCsGAQUFBwEBBEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraS9jZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwEwYDVR0lBAwwCgYI
# KwYBBQUHAwgwDQYJKoZIhvcNAQEFBQADggIBABCXisNcA0Q23em0rXfbznlRTQGx
# LnRxW20ME6vOvnuPuC7UEqKMbWK4VwLLTiATUJndekDiV7uvWJoc4R0Bhqy7ePKL
# 0Ow7Ae7ivo8KBciNSOLwUxXdT6uS5OeNatWAweaU8gYvhQPpkSokInD79vzkeJku
# DfcH4nC8GE6djmsKcpW4oTmcZy3FUQ7qYlw/FpiLID/iBxoy+cwxSnYxPStyC8jq
# cD3/hQoT38IKYY7w17gX606Lf8U1K16jv+u8fQtCe9RTciHuMMq7eGVcWwEXChQO
# 0toUmPU8uWZYsy0v5/mFhsxRVuidcJRsrDlM1PZ5v6oYemIp76KbKTQGdxpiyT0e
# bR+C8AvHLLvPQ7Pl+ex9teOkqHQ1uE7FcSMSJnYLPFKMcVpGQxS8s7OwTWfIn0L/
# gHkhgJ4VMGboQhJeGsieIiHQQ+kr6bv0SMws1NgygEwmKkgkX1rqVu+m3pmdyjpv
# vYEndAYR7nYhv5uCwSdUtrFqPYmhdmG0bqETpr+qR/ASb/2KMmyy/t9RyIwjyWa9
# nR2HEmQCPS2vWY+45CHltbDKY7R4VAXUQS5QrJSwpXirs6CWdRrZkocTdSIvMqgI
# bqBbjCW/oO+EyiHW6x5PyZruSeD3AWVviQt9yGnI5m7qp5fOMSn/DsVbXNhNG6HY
# +i+ePy5VFmvJE6P9MYIEwzCCBL8CAQEwgZAweTELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmlu
# ZyBQQ0ECEzMAAACIWQ48UR/iamcAAQAAAIgwCQYFKw4DAhoFAKCB5TAZBgkqhkiG
# 9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIB
# FTAjBgkqhkiG9w0BCQQxFgQUwvfD5p5mNFuLxmYAV+JJh5wSfcAwgYQGCisGAQQB
# gjcCAQwxdjB0oFqAWABEAEkAQQBHAF8AUwBRAEwAXwBTAEUAVABVAFAAXwBnAGwA
# bwBiAGEAbABfAEQAQwBfAEcAZQB0AFMAUQBMAFMAZQB0AHUAcABMAG8AZwBzAC4A
# cABzADGhFoAUaHR0cDovL21pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEA
# hHlvPtg5FXrxBDsDNI+sxBm5cjsbL0G15oQBXRj5ZkeeLxbdXp7Iy4+32bzgdcus
# XawEQPkCe5ii6sr7t5MLYrXTasCCAnqcpvoKdHu07vwJdOdgtgeFAEgExsBnAw9A
# Y/CBh7OGNS5xHhhxdzr7a9Gp/LY4uptCxvtEyPgm4LvakAqGK9Z++TQM77fdmv2C
# C0Iq7oRyhADdyp4FPLd8IeLqtLu6/bwpFHW3EIPSzDb7xqSUg15OakxQb2Z4kR9B
# lYH24SyGdkIsrUNnnpwPsY5NUh8p2P2/BddPK/Klvq/fVar0T7knY9ohbt8zgL8o
# s/4B15pbxj2Q8ODwokDdVKGCAh8wggIbBgkqhkiG9w0BCQYxggIMMIICCAIBATCB
# hTB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQD
# ExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0ECCmECkkoAAAAAACAwCQYFKw4DAhoF
# AKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTEy
# MDkxMzE4NDQzNVowIwYJKoZIhvcNAQkEMRYEFLSM8rqmMvblmHeY8JIdH7tVv5Vv
# MA0GCSqGSIb3DQEBBQUABIIBAJwE93ILlMmELan/ELqHbxc0RHZvABUvRbnctiIq
# fCgQBalQfof0sZohznWNNPNatHv2NfIqpZ6bucEDVt2l8nlA8+IoRshIAe/WscTb
# L4SyrpvfWnJ1Ie3uHulpXMB2886wXyeC8etJTzksY214MVfBI0SincNVKZs63r1y
# UsOMdXc2ig0PpCZcJNab0IG1W/k4n+jEoY/MWlbtIwIMBeI8h1lJm4bH2KgcdumB
# A+QUmUM1yNhqNYxPAJH8IUepHMkajKiXPRpmMrc4hl2enlLHB0ZLAFZPg5X4+KjN
# v+McOopaazWIikXHdp8mRhqvIleJrEs+IFTZuaq0TaVBTV4=
# SIG # End signature block
