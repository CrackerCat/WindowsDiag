﻿#################################################################################
# Copyright © 2012, Microsoft Corporation. All rights reserved.
#
# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.
#################################################################################
# DC_GetExchange2013Data.ps1
################################################################################# 
#
#
#
#
#
#
#
#################################################################################
# Version 1.0.0
# Date: 9/5/2012
# Author: Brad Hughes - bradhugh@microsoft.com
# Description: Collects Exchange Server 2013 information
#################################################################################

PARAM ([switch]$GetSetupLogs)


$script:RootOutFile = $null
$script:ExchangeServerName = $null
$script:ExchangeVersion = $null


# <summary>
# Write Exchange 2013 Server and role information to the diagnostic report
# </summary>
Function Display-ExchangeServerInfo {
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    # Get our Exchange Server object
    $server = Invoke-ExchangeCommand "Get-ExchangeServer $script:ExchangeServerName" | Select-Object -First 1
    
    $sb = New-Object Text.StringBuilder
    
    # Version
    $sb.AppendFormat("ProductVersion: {0}<br/>", $script:ExchangeVersion) | Out-Null
    
    # TODO: Handle printing IU information
    $sb.AppendFormat("Interim Update: {0}<br/>", "None") | Out-Null
    
	# Site
    $sb.AppendFormat("Site: {0}<br/>", $server.Site) | Out-Null
    
    # Roles
    $sb.AppendFormat("Role(s): {0}", [string]::Join(",",$server.ServerRole)) | Out-Null
    

    
    # Create a new object for the summary
    $summaryObject = New-Object PSCustomObject
    Add-Member -InputObject $summaryObject -MemberType NoteProperty `
        -Name $ExchangeServerName -Value $sb.ToString()
    
    # Update the diagnostic report with the summary object
    # TODO: Get Name from Strings File
    $summaryObject | ConvertTo-Xml2 | Update-DiagReport -Id 00_ExchangeServer_Summary `
        -Name "Exchange Server Version and Role" -Verbosity informational
}

Function Collect-TransportRules {
	 trap [Exception] {
        Log-Error $_
        Continue
    }
	
	ExportResults -cmdlet "Get-TransportRule" -outformat "FL"
	$ExportedTransportRules = Export-TransportRuleCollection
    Set-Content -Path ($script:RootOutFile + "_ExportedTransportRules.xml") -Value $ExportedTransportRules.FileData -Encoding Byte

    $ExportedLegacyTransportRules = Export-TransportRuleCollection -ExportLegacyRules
    Set-Content -Path ($script:RootOutFile + "_ExportedLegacyTransportRules.xml") -Value $ExportedLegacyTransportRules.FileData -Encoding Byte
    CollectFiles -filestocollect ($script:RootOutFile + "_ExportedTransportRules.xml") -filedescription ("Export-TransportRuleCollection") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription
    CollectFiles -filestocollect ($script:RootOutFile + "_ExportedLegacyTransportRules.xml") -filedescription ("Export-TransportRuleCollection -ExportLegacyRules") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription    
}

# <summary>
# Collects todays IIS Logs for all web sites
# </summary>
Function Get-IISLogs {
	trap [Exception] {
		Log-Error $_
		continue
	}
	
	$server = $env:computername
    $iis = [ADSI]"IIS://$server/W3SVC" 
    $sites = $iis.psbase.children | where { $_.keyType -eq "IIsWebServer"}
    foreach($site in $sites){
        $sp = $site.psbase.path
        $lfd = $site.logfiledirectory
        $slf = $sp.substring($sp.indexof("W3SVC")) | %{$_.replace("/","")}
        $w3logpath = Join-Path -Path $lfd -ChildPath $slf
        $tfldr = ($slf + "LogFiles")
        if  (Test-Path $w3logpath){
			# Call CollectCompressedFiles to get the logs
			CompressCollectFiles -FilesToCollect $w3logpath -DestinationFileName "$tfldr.zip" -SectionDescription "Exchange Server IIS Information" -FileDescription "Logs_$slf (todays logs)" -NumberOfDays 1 -Recurse
        }
        Else{
            Write-DebugLog ("Get-IISLogs: IIS Log Path was expected but not found on filesystem: " + $w3logpath)
        }
    }
}

# <summary>
# Gets Logs from the Exchange 2013 logging folder of a certain type
# </summary>
# <param name="$LogKind">The type of log to gather, for example "RPC Client Access"</param>
# <param name="$Days">The number of days of logs to gather (1 by default)</param>
Function Get-ExchangeLogs([string]$LogKind, $Days = 1) {
	$logPath = (Join-Path (Join-Path $global:ExchangeInstallPath "Logging") $LogKind)
	Get-ExchangeLogsFromPath -Path $logPath -LogKind $LogKind -Days $Days
}

# <summary>
# Gets Logs from the Exchange 2013 logging folder of a certain type
# </summary>
# <param name="$Path">The path to the log files</param>
# <param name="$LogKind">The type of log to gather, for example "RPC Client Access"</param>
# <param name="$Days">The number of days of logs to gather (1 by default)</param>
Function Get-ExchangeLogsFromPath([string]$Path, [string]$LogKind, $Days = 1) {
	if (Test-Path $Path) {
		Update-ActivityProgress "$($Strings.ID_GetExch2013DataGatheringLogs): $LogKind"
		CompressCollectFiles -FilesToCollect $Path -DestinationFileName "Logs_$($LogKind).zip" -SectionDescription "Exchange Logging" -FileDescription "Logs_$LogKind ($Days days)" -NumberOfDays $Days -Recurse
	}
	else {
		Write-DebugLog ("ExchangeLogs: could not find log folder: $Path")
	}
}

# <summary>
# Gets role-specific information for the Mailbox Role
# </summary>
Function Get-MailboxRoleData {
    Write-DebugLog "Starting Get-MailboxRoleData"
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    Set-ReportSection "Exchange Mailbox Server Role"
    Set-CurrentActivity ($Strings.ID_GetExchDataCollectingAct + " " + $Strings.ID_GetExchServerMailbox)
    
    Update-ActivityProgress $Strings.ID_GetExchDataWait

    # BEGIN Traditional Mailbox Role style collection
    $mailboxDatabases = Invoke-ExchangeCommand "Get-MailboxDatabase -server $ExchangeServerName"
    
    # Export the Get-MailboxServer Information
    ExportResults -Cmdlet "Get-MailboxServer -identity $Script:ExchangeServerName -Status" -outformat "FL"
    
    # Dump the database information
    $DagNames = @()
    foreach ($mailboxDatabase in $mailboxDatabases) {
        $mbEdbFilePath = Split-Path -Path ($mailboxDatabase.EdbFilePath) -Parent
        $mailboxDatabaseName = ("DBMb_" + $mailboxDatabase.Name + "_")
        $edbFilePathName = ("DBMb_" + $mailboxDatabase.name + "_EDBFilePath_Contents")
        
        ExportResults -Cmdlet "Get-MailboxDatabase '$mailboxDatabase' -Status" -outformat "FL" -filename "$mailboxDatabaseName"
        ExportResults -Cmdlet "Get-ChildItem -Path '$mbEdbFilePath'" -outformat "FT" -filename "$edbFilePathName"
        
		# Use the ToString() for this to make it work in both local/remote PS
        $mbLogFolderPath = $mailboxDatabase.LogFolderPath.ToString()

        # If the logs are in a different place from the EDB, dump that information to a different file
        if ($mbEdbFilePath -ne $mbLogFolderPath){
            $fn = ("DBMb_" + $mailboxDatabase.name + "_LogFolderPath")
            ExportResults -Cmdlet "Get-ChildItem -path '$mbLogFolderPath'" -outformat "FT" -filename "$fn"
        }
        
        # Collect all the DAG names
        if ($mailboxDatabase.MasterType -eq "DatabaseAvailabilityGroup"){
            $DAGnames += $mailboxDatabase.MasterServerOrAvailabilityGroup
        }
    }
    
    # If there are DAG's defined, dump DAG Info
    if ($DAGnames -ne $null){
        $uDagNames = ($DAGNames | Get-Unique)
        foreach($uDAG in $uDagNames){
            ExportResults -cmdlet "Get-DatabaseAvailabilityGroup -id '$uDAG' -Status" -filename "DAG_$uDAG" 
        }
        ExportResults -cmdlet "Get-DatabaseAvailabilityGroupNetwork -server '$ExchangeServerName'" -filename "DAGNetworks" -outformat "FL"
    }
    
    #
    # TODO: Collect new store FCL Logging equivalent
    #
    
    ExportResults -Cmdlet "Get-MailboxDatabaseCopyStatus -Server '$ExchangeServerName'" -outformat "FL"
    ExportResults -Cmdlet "Get-StoreUsageStatistics -Server '$ExchangeServerName'" -outformat "FL"
    
    #
    # REVIEW: Do we need to gather any files in Store's working directory?
    #
    
    # BEGIN Traditional CAS Role style collection
        
    # Get Server-level CAS Data
    
    # POP/IMAP
    ExportResults -cmdlet "Get-PopSettings -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-ImapSettings -Server '$ExchangeServerName'"
    
    # Virtual Directories
    ExportResults -cmdlet "Get-OutlookAnywhere -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-ActiveSyncVirtualDirectory -Server '$ExchangeServerName' -ShowBackEndVirtualDirectories"
    ExportResults -cmdlet "Get-AutodiscoverVirtualDirectory -Server '$ExchangeServerName' -ShowBackEndVirtualDirectories"
    ExportResults -cmdlet "Get-OabVirtualDirectory -Server '$ExchangeServerName' -ShowBackEndVirtualDirectories"
    ExportResults -cmdlet "Get-OwaVirtualDirectory -Server '$ExchangeServerName' -ShowBackEndVirtualDirectories"
    ExportResults -cmdlet "Get-EcpVirtualDirectory -Server '$ExchangeServerName' -ShowBackEndVirtualDirectories"
    ExportResults -cmdlet "Get-PowerShellVirtualDirectory -Server '$ExchangeServerName' -ShowBackEndVirtualDirectories"
    ExportResults -cmdlet "Get-WebServicesVirtualDirectory -Server '$ExchangeServerName' -ShowBackEndVirtualDirectories"
    
    # Dump RpcProxy registry keys
    $regkeys = "HKLM:SOFTWARE\Microsoft\Rpc\RpcProxy"
    $outfile = ($script:RootOutFile + "_REG_RPCPROXY.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:SOFTWARE\Microsoft\Rpc\RpcProxy*") -sectiondescription (Get-ReportSection) -Recursive $true
	
	# Get RpcHttp logs from MBX
	Get-ExchangeLogs -LogKind "RpcHttp" -Days 1
	
	# Get RPCClientAccess logs
	Get-ExchangeLogs -LogKind "RPC Client Access" -Days 1
	
	# Get AddressBook service logs
	Get-ExchangeLogs -LogKind "AddressBook Service" -Days 1
	
	# Get today's Hybrid Config Logs
	Get-ExchangeLogs -LogKind "Update-HybridConfiguration" -Days 1
    
    # BEGIN Traditional Hub Role style collection
    
	# Server-Level
    ExportResults -cmdlet "Get-TransportService -Identity '$ExchangeServerName'"
    ExportResults -cmdlet "Get-ReceiveConnector -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-Queue -Server '$ExchangeServerName'"
	ExportResults -cmdlet "Get-MailboxTransportService -Identity '$ExchangeServerName'"
	
	# These cmdlets run implicitly on the server you're connected to and aren't remotable
	ExportResults -cmdlet "Get-TransportAgent"
    ExportResults -cmdlet "Get-TransportPipeline"
	ExportResults -cmdlet "Get-EdgeSyncServiceConfig"
	
	$transportService = Invoke-ExchangeCommand "Get-TransportService -Identity $ExchangeServerName"
	
	# Get today's QueueViewer log
	$queueViewerLogPath = $transportService.QueueLogPath.ToString()
	Get-ExchangeLogsFromPath -Path $queueViewerLogPath -LogKind "QueueViewer" -Days 1
	
	# Today's message tracking logs
	$messageTrackingLogPath = $transportService.MessageTrackingLogPath.ToString()
    Get-ExchangeLogsFromPath -Path $messageTrackingLogPath -LogKind "MessageTracking" -Days 1
	
	# Today's routing logs
    $routingLogPath = $transportService.RoutingTableLogPath.ToString()
	Get-ExchangeLogsFromPath -Path $routingLogPath -LogKind "BE_Routing" -Days 1

    # Today's agent logs
	$agentLogPath = $transportService.AgentLogPath.ToString()
    Get-ExchangeLogsFromPath -Path $agentLogPath -LogKind "BE_Agent" -Days 1
	
	# BEGIN Traditional UM Role style collection
    
	# UM Server collection
    ExportResults -cmdlet "Get-UMService -identity '$ExchangeServerName'"
}

# <summary>
# Gets role-specific information for the CAS Role
# </summary>
Function Get-ClientAccessRoleData {
    Write-DebugLog "Starting Get-ClientAccessRoleData"
	trap [Exception] {
        Log-Error $_
        Continue
    }
	
	Set-ReportSection "Exchange Client Access Server Role"
    Set-CurrentActivity ($Strings.ID_GetExchDataCollectingAct + " " + $Strings.ID_GetExchServerCAS)
	
	# Get CAS Information
    ExportResults -cmdlet "Get-ClientAccessServer -Identity '$ExchangeServerName'"
	
	# Server Collection
	ExportResults -cmdlet "Get-PopSettings -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-ImapSettings -Server '$ExchangeServerName'"
    
	# Virtual Directories
    ExportResults -cmdlet "Get-OutlookAnywhere -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-ActiveSyncVirtualDirectory -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-AutodiscoverVirtualDirectory -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-OabVirtualDirectory -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-OwaVirtualDirectory -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-EcpVirtualDirectory -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-PowerShellVirtualDirectory -Server '$ExchangeServerName'"
    ExportResults -cmdlet "Get-WebServicesVirtualDirectory -Server '$ExchangeServerName'"
	
	# Get HttpProxy and RPCHttpLogs
	Get-ExchangeLogs -LogKind "RpcHttp" -Days 1
	Get-ExchangeLogs -LogKind "HttpProxy" -Days 1
	
	# FrontEndTransport collection
	ExportResults -cmdlet "Get-FrontendTransportService -Identity '$ExchangeServerName'"
	ExportResults -cmdlet "Get-ReceiveConnector -Server '$ExchangeServerName'"

    $frontEndTransport = Invoke-ExchangeCommand "Get-FrontendTransportService -Identity $ExchangeServerName"
	
	# Today's routing logs
	# This path isn't accessible on a front-end through the FrontendTransportService config
	# So build the default location here
	$routingLogPath = Join-Path $global:ExchangeInstallPath "TransportRoles\Logs\Routing"
	Get-ExchangeLogsFromPath -Path $routingLogPath -LogKind "FE_Routing" -Days 1
	
	# Today's connectivity Logs for FrontEndTransport
	$feConnectivityLogPath = Join-Path $global:ExchangeInstallPath "TransportRoles\Logs\FrontEnd\Connectivity"
	Get-ExchangeLogsFromPath -Path $feConnectivityLogPath -LogKind "FE_Connectivity" -Days 1

    # Today's agent logs
	$agentLogPath = $frontEndTransport.AgentLogPath.ToString()
    Get-ExchangeLogsFromPath -Path $agentLogPath -LogKind "FE_Agent" -Days 1

	# Once we figure out the local vs remote PS story
	# These cmdlets run implicitly on the server you're connected to and aren't remotable
	ExportResults -cmdlet "Get-TransportAgent" -Local
	ExportResults -cmdlet "Get-TransportPipeline" -Local
	ExportResults -cmdlet "Get-EdgeSyncServiceConfig" -Local
	
	# UM Cmdlets that are also not remotable
	ExportResults -cmdlet "Get-UMCallRouterSettings" -Local
}

# <summary>
# Gets common Exchange 2013 data
# </summary>
Function Get-CommonData { 
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    Write-DebugLog "Starting Get-CommonData"
    
    Set-ReportSection "Exchange Server and Organization Baseline"
    Set-CurrentActivity ($Strings.ID_GetExchDataCollectingAct + " " + $Strings.ID_GetExchServerCommon)
    Update-ActivityProgress $Strings.ID_GetExchDataWait
        
    # Get the Exchange Build Version
    $exSetup = Join-Path $global:ExchangeInstallPath "\bin\exsetup.exe"
    $script:ExchangeVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($exSetup).ProductVersion
    
    # TODO: Detect Interim Updates
    
    # Display Exchange Server Info
    Display-ExchangeServerInfo
    
    # Local Server
    ExportResults -cmdlet "Write-Output '$Script:ExchangeServerName exsetup.exe ProductVersion:  $script:ExchangeVersion' ; Get-ExchangeServer | Select-Object Name,AdminDisplayVersion,ServerRole,Site" -outformat "FL" -filename "AllExchangeServers" -filedescription "All Exchange Servers - Versions-Roles-Site"
    ExportResults -cmdlet "Get-ExchangeCertificate -Server $Script:ExchangeServerName" -outformat "FL" -filename "ExchangeCertificate"
    ExportResults -cmdlet "Get-ExchangeServer -identity $Script:ExchangeServerName -status"
    ExportResults -cmdlet "Get-PowerShellVirtualDirectory -Server $Script:ExchangeServerName" -outformat "FL"
	ExportResults -cmdlet "Get-MalwareFilteringServer -Identity $Script:ExchangeServerName"
	ExportResults -cmdlet "Get-ServerHealth -Identity $Script:ExchangeServerName" -outformat "FL"
	ExportResults -cmdlet "Get-ServerComponentState -Identity $Script:ExchangeServerName" -outformat "FL"
    
    # Organization Stuff
	ExportResults -cmdlet "Get-OrganizationConfig"
	ExportResults -cmdlet "Get-UserPrincipalNamesSuffix"
	ExportResults -cmdlet "Get-WorkloadManagementPolicy"
	ExportResults -cmdlet "Get-WorkloadPolicy"
	ExportResults -cmdlet "Get-ResourcePolicy"
	ExportResults -cmdlet "Get-SiteMailboxProvisioningPolicy"
	ExportResults -cmdlet "Get-AddressBookPolicy"
	
	# Transport Organization
    #ExportResults -cmdlet "Get-AcceptedDomain" #removing to test reported hang on activity after this cmdlet
    ExportResults -cmdlet "Get-RemoteDomain" 
    ExportResults -cmdlet "Get-EmailAddressPolicy"
	ExportResults -cmdlet "Get-SendConnector"
	ExportResults -cmdlet "Get-EdgeSubscription"
	ExportResults -cmdlet "Get-TransportConfig"
	ExportResults -cmdlet "Get-EdgeSyncServiceConfig"
	ExportResults -cmdlet "Get-DataClassification | where { `$_.Publisher -notlike 'Microsoft*' }" -outformat "FL" -filename "ThirdPartyDataClassifications"
	ExportResults -cmdlet "Get-DlpPolicyTemplate | where { `$_.PublisherName -notlike 'Microsoft*' }" -outformat "FL" -filename "ThirdPartyDplPolicyTemplates"
	ExportResults -cmdlet "Get-DlpPolicy"
	ExportResults -cmdlet "Get-MalwareFilterPolicy"
	ExportResults -cmdlet "Get-PolicyTipConfig"
	
	# Client Access Organization
    ExportResults -cmdlet "Get-AvailabilityAddressSpace"
    ExportResults -cmdlet "Get-AvailabilityConfig"
    ExportResults -cmdlet "Get-ThrottlingPolicy"
	ExportResults -cmdlet "Get-ActiveSyncMailboxPolicy"
	ExportResults -cmdlet "Get-ActiveSyncDeviceAutoblockThreshold"
	ExportResults -cmdlet "Get-MobileDeviceMailboxPolicy"
    ExportResults -cmdlet "Get-OutlookProvider"
	#ExportResults -cmdlet "Get-App" #Eliminated 9/26/13 - Long running, low ROI
	
	# UM Organization
	ExportResults -cmdlet "Get-UMDialPlan"
    ExportResults -cmdlet "Get-UMIPGateway"
    ExportResults -cmdlet "Get-UMHuntGroup"
    ExportResults -cmdlet "Get-UMMailboxPolicy"
    ExportResults -cmdlet "Get-UMAutoAttendant"
	
	foreach ($dialplan in (Invoke-ExchangeCommand "Get-UMDialPlan")) {
        $cFileDialPlanName = ("UMDialPlan_" + $dialplan.Name + "_CountryOrRegionGroups")
        $iFileDialPlanName = ("UMDialPlan_" + $dialplan.Name + "_InternationalGroups")
        ExportResults -cmdlet "(Get-UMDialPlan $dialplan.Name).ConfiguredInCountryOrRegionGroups" -filename "'$cFileDialPlanName'" -cmdletDescription "Get-UMDialPlan (InCountryOrRegionGroups)"
        ExportResults -cmdlet "(Get-UMDialPlan $dialplan.Name).ConfiguredInternationalGroups" -filename "'$iFileDialPlanName'" -cmdletDescription "Get-UMDialPlan (ConfiguredInternationalGroups)"
    }
	
	foreach ($UMAutoAttendant in (Invoke-ExchangeCommand "Get-UMAutoAttendant")) {
        $bFileUMAAName = ("UMAutoAttendant_" + $UMAutoAttendant.Name + "_BusinessHoursKeyMapping")
        $aFileUMAAName = ("UMAutoAttendant_" + $UMAutoAttendant.Name + "_AfterHoursKeyMapping")
        ExportResults -cmdlet "(Get-UMAutoAttendant $UMAutoAttendant.Name).BusinessHoursKeyMapping" -filename "'$bFileUMAAName'" -cmdletDescription "Get-UMAutoAttendant (BusinessHoursKeyMapping)"
        ExportResults -cmdlet "(Get-UMAutoAttendant $UMAutoAttendant.Name).AfterHoursKeyMapping" -filename "'$aFileUMAAName'" -cmdletDescription "Get-UMAutoAttendant (AfterHoursKeyMapping)"
    }
    
    # If they have a Federation trust configured, dump related information
    If (Invoke-ExchangeCommand "Get-FederationTrust"){
        ExportResults -cmdlet "Get-FederationTrust"
        ExportResults -cmdlet "Test-FederationTrustCertificate"
        ExportResults -cmdlet "Get-FederatedOrganizationIdentifier -IncludeExtendedDomainInfo -Verbose"
        ExportResults -cmdlet "Get-OrganizationRelationship"
    }
    
	# Get IIS Logs
	Get-IISLogs
}


# <summary>
# Main Exchange Data Collection Function
# </summary>
Function Get-Exchange2013Data {
    "Starting Get-Exchange2013Data" | WriteTo-StdOut
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    # Global Variable initialization
    $script:RootOutFile = Join-Path $PWD.Path.ToString() $env:COMPUTERNAME
    
    if ($global:ExchangeVersion -eq 15) {
        if (-not ($global:CasRoleInstalled -or $global:MbxRoleInstalled)) {
            Write-DebugLog "This is an Admin Tools only installation, please run on the server"
            return
        }
        
        # Set the Exchange Server name variable
        $script:ExchangeServerName = $env:COMPUTERNAME
		
		# Initialize the Exchange Runspace and load the Management Shell
		Set-CurrentActivity $Strings.ID_GetExch2013DataInit
		Update-ActivityProgress $Strings.ID_GetExch2013DataConnectEMS
		
		# Just trigger the load at startup, we don't need it yet
		Get-ExchangeRemoteRunspace | Out-Null
    }
    else {
        Write-DebugLog "Exchange 2013 is not installed"
        return
    }
	
    # Get Common Data for all Server Roles
    Get-CommonData
    
    # Get CAS Role Data if installed
    if ($global:CasRoleInstalled) { Get-ClientAccessRoleData }
    
    # Get Mailbox Role Data if installed
    if ($global:MbxRoleInstalled) { Get-MailboxRoleData }
	
}

# Main Script Body

#======================================
# Load localized strings
#======================================
Import-LocalizedData -BindingVariable Strings -ErrorAction SilentlyContinue

#======================================
# Set global variables regardless of Exchange version inestalled
#======================================
$global:SystemDrv = (Get-ChildItem env:systemdrive).value
$formatenumerationlimit = 128

#======================================
# Tracks Script Execution count and disables confirmation
#======================================
$script:count = 0
$ConfirmPreference = "NONE"

If ($getSetupLogs) { $script:paramGetSetupLogs = $true }

#======================================
# Call the  Get-Exchange2013Data function
#======================================
"Calling Get-Exchange2013Data" | WriteTo-StdOut
Get-Exchange2013Data

# Collect Debug logs
Collect-DebugLog

# SIG # Begin signature block
# MIIbAwYJKoZIhvcNAQcCoIIa9DCCGvACAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUX/QTvoZMVvsAWxWA9ChSQ6B6
# arOgghWCMIIEwzCCA6ugAwIBAgITMwAAAEyh6E3MtHR7OwAAAAAATDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTMxMTExMjIxMTMx
# WhcNMTUwMjExMjIxMTMxWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsdj6GwYrd6jk
# lF18D+Z6ppLuilQdpPmEdYWXzMtcltDXdS3ZCPtb0u4tJcY3PvWrfhpT5Ve+a+i/
# ypYK3EbxWh4+AtKy4CaOAGR7vjyT+FgyeYfSGl0jvJxRxA8Q+gRYtRZ2buy8xuW+
# /K2swUHbqs559RyymUGneiUr/6t4DVg6sV5Q3mRM4MoVKt+m6f6kZi9bEAkJJiHU
# Pw0vbdL4d5ADbN4UEqWM5zYf9IelsEEXb+NNdGbC/aJxRjVRzGsXUWP6FZSSml9L
# KLrmFkVJ6Sy1/ouHr/ylbUPcpjD6KSjvmw0sXIPeEo1qtNtx71wUWiojKP+BcFfx
# jAeaE9gqUwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFLkNrbNN9NqfGrInJlUNIETY
# mOL0MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAAmKTgav6O2Czx0HftcqpyQLLa+aWyR/lHEMVYgkGlIVY+KQ
# TQVKmEqc++GnbWhVgrkp6mmpstXjDNrR1nolN3hnHAz72ylaGpc4KjlWRvs1gbnk
# PUZajuT8dTdYWUmLTts8FZ1zUkvreww6wi3Bs5tSLeA1xbnBV7PoPaE8RPIjFh4K
# qlk3J9CVUl6ofz9U8IHh3Jq9ZdV49vdMObvd4NY3DpGah4xz53FkUvc+A9jGzXK4
# NDSYW4zT9Qim63jGUaANDm/0azxAGmAWLKkGUp0cE5DObwIe6nucs/b4l2DyZdHR
# H4c6wXXwQo167Yxysnv7LIq0kUdU4i5pzBZUGlkwggTsMIID1KADAgECAhMzAAAA
# sBGvCovQO5/dAAEAAACwMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTEzMDEyNDIyMzMzOVoXDTE0MDQyNDIyMzMzOVowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOivXKIgDfgofLwFe3+t7ut2rChTPzrbQH2zjjPmVz+l
# URU0VKXPtIupP6g34S1Q7TUWTu9NetsTdoiwLPBZXKnr4dcpdeQbhSeb8/gtnkE2
# KwtA+747urlcdZMWUkvKM8U3sPPrfqj1QRVcCGUdITfwLLoiCxCxEJ13IoWEfE+5
# G5Cw9aP+i/QMmk6g9ckKIeKq4wE2R/0vgmqBA/WpNdyUV537S9QOgts4jxL+49Z6
# dIhk4WLEJS4qrp0YHw4etsKvJLQOULzeHJNcSaZ5tbbbzvlweygBhLgqKc+/qQUF
# 4eAPcU39rVwjgynrx8VKyOgnhNN+xkMLlQAFsU9lccUCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBRZcaZaM03amAeA/4Qevof5cjJB
# 8jBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# NGZhZjBiNzEtYWQzNy00YWEzLWE2NzEtNzZiYzA1MjM0NGFkMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQAx124qElczgdWdxuv5OtRETQie
# 7l7falu3ec8CnLx2aJ6QoZwLw3+ijPFNupU5+w3g4Zv0XSQPG42IFTp8263Os8ls
# ujksRX0kEVQmMA0N/0fqAwfl5GZdLHudHakQ+hywdPJPaWueqSSE2u2WoN9zpO9q
# GqxLYp7xfMAUf0jNTbJE+fA8k21C2Oh85hegm2hoCSj5ApfvEQO6Z1Ktwemzc6bS
# Y81K4j7k8079/6HguwITO10g3lU/o66QQDE4dSheBKlGbeb1enlAvR/N6EXVruJd
# PvV1x+ZmY2DM1ZqEh40kMPfvNNBjHbFCZ0oOS786Du+2lTqnOOQlkgimiGaCMIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBOswggTn
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAsBGvCovQO5/d
# AAEAAACwMAkGBSsOAwIaBQCgggEDMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBTE
# DtUArfvtI0olEs1y95zO0TXO7jCBogYKKwYBBAGCNwIBDDGBkzCBkKB2gHQARABJ
# AEEARwBfAEMAVABTAF8ARwBlAG4AZQByAGEAbABfAFIAZQBwAG8AcgB0AHMAXwBn
# AGwAbwBiAGEAbABfAEQAQwBfAEcAZQB0AEUAeABjAGgAYQBuAGcAZQAyADAAMQAz
# AEQAYQB0AGEALgBwAHMAMaEWgBRodHRwOi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBFifVDQDlImJX9Ao/tdW1YY6MQ3wV8dd5QTBCi1G8q+ztYFEta
# 15K2tlDIrAnXA78H4ARLcfm4jUxXl81G50LOsLjyVcRYIOTx1Ek+NBFOkQ3kA/93
# CQ4AzRGyFIPnXlQ42XLfH0y19v20bcLCjVTkNSD8+j5BcyqDvjBigIPfA/SxfIW5
# YPmKJsWNxZawZZUS6y8wX2T26bI0Yt0eR0LOksuCoyFLU5b3ggEPyT1XIRwUEb/7
# IlROuK8aCSM8pj0O9M8WgUUnss/KJhMN2ctiNarXcgdUXDxdjLGOuS4YdIrPD5Ol
# bf2rnkl9X+woty3hlsbmvMBCFu/wJRzoYB3FoYICKDCCAiQGCSqGSIb3DQEJBjGC
# AhUwggIRAgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQQITMwAAAEyh6E3M
# tHR7OwAAAAAATDAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEH
# ATAcBgkqhkiG9w0BCQUxDxcNMTQwMjI0MTczNzU3WjAjBgkqhkiG9w0BCQQxFgQU
# hIto6niDKX6yb1Xmilu0UgabnSMwDQYJKoZIhvcNAQEFBQAEggEAIs9Ob2/ypZSD
# 7yqmjY5QMHbq3ZZ3ykTlegUkm/ItTV3//BOCxetU19pQI+bK71IzkUJ8fQPojD1B
# 9NwKvXPBvRswZT1ss6qygEjC9/lc1fV9SKiN8vLVJyOgEB8YaoSTWsY0pNVypjc2
# SHH6zWWT/QYquP16+tNxnM0kcPtz439+Ys+n9Gxc+ns9DEvqnMLxSLFRHZe8xdWj
# cIzQC0JcNa8gxZtPc3kxnplekCbiuffbc7F8NIrnOm85cHas2gRG/199eJmbrOz8
# boa/rqL/zn9vKrXWfUbGfzYkc3Ze6YykwnXtkOUi7w/1AUqreqI+gsFs+EeCy2g+
# ENtw32uEug==
# SIG # End signature block
