﻿# Copyright ?2008, Microsoft Corporation. All rights reserved.

# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.

# 2019-03-17 WalterE added Trap #_#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

. ./utils_cts.ps1
SkipSecondExecution

$EventLogAlertXMLFileName = $Computername + "_EventLogAlerts.XML"

if (Test-Path $EventLogAlertXMLFileName) 
{
	if($debug -eq $true){[void]$shell.popup($EventLogAlertXMLFileName)}
	
	[xml] $XMLResults = Get-Content -Path $EventLogAlertXMLFileName

	$XMLResults.SelectNodes("//Alert") | Sort-Object -Property  @{Expression={$_.Priority};Descending=$true} | ForEach-Object -Process {
		if ($_.SelectSingleNode("Objects/Object[not(Property[@Name=`"SkipRootCauseDetection`"])]") -ne $null)
		{
			$_.InnerXML | Update-DiagReport -id 00_EventLog -Name $_.Category -verbosity $_.Type
			if($debug -eq $true){[void]$shell.popup($_.InnerXML)}
		}
	}
	
	Remove-Item $EventLogAlertXMLFileName
}